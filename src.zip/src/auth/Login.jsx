import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';


const AuthPage = () => {
  const [activeTab, setActiveTab] = useState('login');

  const navigate =useNavigate()

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        
        {/* Main Folder-Style Card */}
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden border border-gray-200">
          
          {/* Tab Navigation (Inside the card) */}
          <div className="flex bg-gray-50/50">
            <button
              onClick={() => setActiveTab('login')}
              className={`flex-1 py-4 text-sm font-semibold transition-all duration-200 ${
                activeTab === 'login'
                  ? 'bg-white text-brand-600 shadow-[0_2px_0_0_#0f172a_inset]'
                  : 'text-gray-400 hover:text-gray-600 hover:bg-gray-50'
              }`}
            >
              Sign In
            </button>
         
          </div>

          {/* Form Content Area */}
          <div className="p-8">
            <div className="mb-8">
              <h2 className="text-2xl font-bold tracking-tight">
                {activeTab === 'login' ? 'Welcome back' : 'Join us today'}
              </h2>
              <p className="text-sm text-gray-500 mt-2">
                {activeTab === 'login' 
                  ? 'Enter your credentials to access your account.' 
                  : 'Fill in your details to get started.'}
              </p>
            </div>

            <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
             
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                <input
                  type="email"
                  placeholder="you@example.com"
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-sm font-medium text-gray-700">Password</label>
                  {activeTab === 'login' && (
                    <a href="#" className="text-xs font-semibold text-brand-500 hover:text-brand-600">
                      Forgot password?
                    </a>
                  )}
                </div>
                <input
                  type="password"
                  placeholder="••••••••"
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all"
                />
              </div>

              <button
                type="submit"
                onClick={()=>(navigate('/'))}
                className="w-full bg-brand-500 text-white font-semibold py-3 rounded-lg hover:bg-brand-600 transition-colors mt-6 shadow-md"
              >
                {activeTab === 'login' ? 'Sign In' : 'Create Account'}
              </button>
            </form>
          </div>
        </div>

      </div>
    </div>
  );
};

export default AuthPage;