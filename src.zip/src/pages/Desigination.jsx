import React, { useState } from 'react';
import DataTable from '../components/reusable/DataTable';
import SubtleButton from '../components/reusable/SubtleButton';

export default function Designation() {
  // Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);

  // 1. Updated the data to reflect designations and aligned the object keys
  const designationData = [
    {
      id: 1,
      sl: 1,
      designationHead: 'James Anderson',
      designationName: 'Principal Engineer',
    },
    {
      id: 2,
      sl: 2,
      designationHead: 'Michael Davis',
      designationName: 'Lead Designer',
    },
    {
      id: 3,
      sl: 3,
      designationHead: 'Matthew Taylor',
      designationName: 'IT Manager',
    },
    {
      id: 4,
      sl: 4,
      designationHead: 'Sarah Connor',
      designationName: 'HR Director',
    },
    {
      id: 5,
      sl: 5,
      designationHead: 'Robert King',
      designationName: 'Marketing Specialist',
    },
  ];

  // 2. Updated column keys to match the camelCase keys in the data above
  const tableColumns = [
    { key: 'sl', label: 'SL' },
    { key: 'designationHead', label: 'Report To' },
    { key: 'designationName', label: 'Designation' },
    {
      key: 'actions',
      label: 'Action',
      render: () => (
        <button className="px-2 border border-gray-200 py-1 bg-white rounded-md text-gray-500 hover:bg-gray-50 transition-colors shadow-sm">
          •••
        </button>
      ),
    },
  ];

  return (
    <div className="h-full overflow-y-auto">
      <div className="p-4">
        {/* Add Designation Button */}
        <div onClick={() => setIsModalOpen(true)} className="inline-block mb-4 cursor-pointer">
          <SubtleButton variant="custom">+ Add Designation</SubtleButton>
        </div>

        <DataTable
          title="Designation Directory"
          columns={tableColumns}
          data={designationData}
        />
      </div>

      {/* --- Overlay Backdrop --- */}
      <div
        className={`fixed inset-0 bg-black/20 z-40 transition-opacity duration-300 ${
          isModalOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setIsModalOpen(false)}
      />

      {/* --- Right Side Drawer --- */}
      <div
        className={`fixed inset-y-0 right-0 z-50 w-full max-w-md bg-white shadow-2xl transform transition-transform duration-300 ease-in-out flex flex-col ${
          isModalOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        {/* Drawer Header (Fixed at top) */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 bg-white">
          <h2 className="text-xl font-semibold text-gray-800">Add Designation</h2>
          <button
            onClick={() => setIsModalOpen(false)}
            className="text-gray-400 hover:text-gray-600 transition-colors p-1"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>

        {/* Drawer Body / Form (Scrollable) */}
        <div className="flex-1 overflow-y-auto">
          <form className="p-6">
            <div className="grid grid-cols-1 gap-5">
              
              {/* Designation Name */}
              <div>
                <label className="block text-sm font-medium text-slate-500 mb-1">
                  Designation Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Senior Frontend Developer"
                  className="w-full px-3 py-2 border border-gray-200 rounded-md bg-slate-50 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                />
              </div>

              {/* Report To (Select) */}
              <div>
                <label className="block text-sm font-medium text-slate-500 mb-1">
                  Report To
                </label>
                <select className="w-full px-3 py-2 border border-gray-200 rounded-md text-slate-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 appearance-none bg-white">
                  <option value="">Select Manager / Head</option>
                  <option value="James Anderson">James Anderson</option>
                  <option value="Michael Davis">Michael Davis</option>
                  <option value="Matthew Taylor">Matthew Taylor</option>
                  <option value="Sarah Connor">Sarah Connor</option>
                  <option value="Robert King">Robert King</option>
                </select>
              </div>

            </div>

            {/* Drawer Footer / Actions */}
            <div className="mt-8 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 font-medium px-4 py-2 rounded-md transition-colors shadow-sm"
              >
                Cancel
              </button>
              <button
                type="button"
                className="bg-emerald-500 hover:bg-emerald-600 text-white font-medium px-6 py-2 rounded-md transition-colors shadow-sm"
              >
                Save
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}