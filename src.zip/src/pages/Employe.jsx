import React, { useState } from 'react';
import DataTable from '../components/reusable/DataTable';
import SubtleButton from '../components/reusable/SubtleButton';

export default function Employe() {
  // Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [openDropdownId, setOpenDropdownId] = useState(null);

  // 1. Updated mock data with Email, Designation, Phone, and Department
  const employeeData = [
    {
      id: 1,
      name: 'James Anderson',
      avatar: 'https://i.pravatar.cc/150?u=1',
      email: 'james.anderson@example.com',
      designation: 'Senior Developer',
      phone: '+1 (555) 123-4567',
      department: 'Engineering',
    },
    {
      id: 2,
      name: 'William Johnson',
      avatar: 'https://i.pravatar.cc/150?u=2',
      email: 'william.j@example.com',
      designation: 'Full-Stack Developer',
      phone: '+1 (555) 234-5678',
      department: 'Engineering',
    },
    {
      id: 3,
      name: 'Benjamin Martinez',
      avatar: 'https://i.pravatar.cc/150?u=3',
      email: 'ben.martinez@example.com',
      designation: 'Mobile App Developer',
      phone: '+1 (555) 345-6789',
      department: 'Mobile Team',
    },
    {
      id: 4,
      name: 'Michael Davis',
      avatar: 'https://i.pravatar.cc/150?u=4',
      email: 'michael.davis@example.com',
      designation: 'UI/UX Designer',
      phone: '+1 (555) 456-7890',
      department: 'Design',
    },
    {
      id: 5,
      name: 'Matthew Taylor',
      avatar: 'https://i.pravatar.cc/150?u=5',
      email: 'matt.taylor@example.com',
      designation: 'DevOps Engineer',
      phone: '+1 (555) 567-8901',
      department: 'IT & Infrastructure',
    },
  ];


const handleEdit = (row) => {
    console.log('Editing row:', row);
    // Add your edit logic here (e.g., opening the modal and setting form values)
  };

  const handleDelete = (id) => {
    console.log('Deleting row with ID:', id);
    if (window.confirm('Are you sure you want to delete this designation?')) {
      // Perform delete
    }
  };

  const toggleDropdown = (id) => {
    // If clicking the same row's button, close it. Otherwise, open the new one.
    setOpenDropdownId((prevId) => (prevId === id ? null : id));
  };


  // 2. Define your columns with the new requested fields
  const tableColumns = [
    {
      key: 'name',
      label: 'Name',
      render: (row) => (
        <div className="flex items-center gap-3">
          <img src={row.avatar} alt={row.name} className="w-8 h-8 rounded-full object-cover" />
          <span className="font-medium text-slate-900">{row.name}</span>
        </div>
      ),
    },
    { key: 'email', label: 'Email' },
    { key: 'designation', label: 'Designation' },
    { key: 'phone', label: 'Phone' },
    { key: 'department', label: 'Department' },
    {
      key: 'actions',
      label: 'Action',
     render: (row) => (
        <div className="relative inline-block text-left">
          <button 
            onClick={() => toggleDropdown(row.id)}
            className="px-2 border border-gray-200 py-1 bg-white rounded-md text-gray-500 hover:bg-gray-50 transition-colors shadow-sm"
          >
            •••
          </button>

          {/* Dropdown Menu */}
          {openDropdownId === row.id && (
            <div className="absolute right-0 mt-2 w-28 bg-white border border-gray-200 rounded-md shadow-lg z-10 overflow-hidden">
              <button
                onClick={() => {
                  handleEdit(row);
                  setOpenDropdownId(null); // Close menu after clicking
                }}
                className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-slate-50 transition-colors"
              >
                Edit
              </button>
              <button
                onClick={() => {
                  handleDelete(row.id);
                  setOpenDropdownId(null); // Close menu after clicking
                }}
                className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors"
              >
                Delete
              </button>
            </div>
          )}
        </div>
      ),
    },
  ];

  return (
   <div className="h-full overflow-y-auto">
      <div className="p-4">
        {/* Add Designation Button */}
        <div onClick={() => setIsModalOpen(true)} className="inline-block mb-4 cursor-pointer">
          <SubtleButton variant="custom">+ Add Employee</SubtleButton>
          {/* <button className='w-full bg-[#8A2BE2] hover:bg-[#9B4DFF] text-white py-3 rounded-xl text-sm font-medium transition-colors flex items-center justify-center space-x-2'>Add</button> */}
        </div>
        
        <DataTable 
          title="Employee Directory" 
          columns={tableColumns} 
          data={employeeData} 
          
        />
      </div>

      {/* --- Overlay Backdrop --- */}
      <div 
        className={`fixed inset-0 bg-black/20 z-40 transition-opacity duration-300 ${
          isModalOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setIsModalOpen(false)}
      />

      {/* --- Right Side Drawer --- */}
      <div 
        className={`fixed inset-y-0 right-0 z-50 w-full max-w-md bg-white shadow-2xl transform transition-transform duration-300 ease-in-out flex flex-col ${
          isModalOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        {/* Drawer Header (Fixed at top) */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 bg-white">
          <h2 className="text-xl font-semibold text-gray-800">Add Employee</h2>
          <button 
            onClick={() => setIsModalOpen(false)}
            className="text-gray-400 hover:text-gray-600 transition-colors p-1"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Drawer Body / Form (Scrollable) */}
        <div className="flex-1 overflow-y-auto">
          <form className="p-6">
            <div className="grid grid-cols-1 gap-5">
              
              {/* Full Name */}
              <div>
                <label className="block text-sm font-medium text-slate-500 mb-1">Full Name</label>
                <input 
                  type="text" 
                 placeholder="Enter your Name"
                  className="w-full px-3 py-2 border border-gray-200 rounded-md bg-slate-50 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                />
              </div>

              {/* Email Address */}
              <div>
                <label className="block text-sm font-medium text-slate-500 mb-1">Email Address</label>
                <input 
                  type="email" 
                  placeholder="Enter your Email"
                  className="w-full px-3 py-2 border border-gray-200 rounded-md bg-slate-50 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                />
              </div>

              {/* Phone Number */}
              <div>
                <label className="block text-sm font-medium text-slate-500 mb-1">Phone Number</label>
                <input 
                  type="text" 
                  defaultValue="+91 9876543210"
                  className="w-full px-3 py-2 border border-gray-200 rounded-md focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                />
              </div>

              {/* Department */}
              <div>
                <label className="block text-sm font-medium text-slate-500 mb-1">Department</label>
                <select className="w-full px-3 py-2 border border-gray-200 rounded-md text-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 appearance-none bg-white">
                  <option>Select Department</option>
                  <option>Engineering</option>
                  <option>Design</option>
                  <option>HR</option>
                </select>
              </div>

              {/* Designation */}
              <div>
                <label className="block text-sm font-medium text-slate-500 mb-1">Designation</label>
                <input 
                  type="text" 
                  placeholder="e.g. Software Engineer"
                  className="w-full px-3 py-2 border border-gray-200 rounded-md focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                />
              </div>

              {/* Joining Date */}
              <div>
                <label className="block text-sm font-medium text-slate-500 mb-1">Joining Date</label>
                <input 
                  type="date" 
                  className="w-full px-3 py-2 border border-gray-200 rounded-md focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-transparent hover:text-inherit focus:text-inherit"
                />
              </div>

              {/* Employment Status */}
              <div>
                <label className="block text-sm font-medium text-slate-500 mb-1">Employment Status</label>
                <select className="w-full px-3 py-2 border border-gray-200 rounded-md focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-slate-600 bg-white">
                  <option>Active</option>
                  <option>On Leave</option>
                  <option>Terminated</option>
                </select>
              </div>

              {/* Address */}
              <div>
                <label className="block text-sm font-medium text-slate-500 mb-1">Address</label>
                <textarea 
                  placeholder="Enter address"
                  rows="3"
                  className="w-full px-3 py-2 border border-gray-200 rounded-md focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 resize-none"
                ></textarea>
              </div>

              {/* Profile Photo */}
              <div>
                <label className="block text-sm font-medium text-slate-500 mb-1">Profile Photo</label>
                <div className="flex border border-gray-200 rounded-md overflow-hidden bg-white">
                  <label className="px-4 py-2 bg-slate-50 text-slate-500 border-r border-gray-200 cursor-pointer hover:bg-slate-100 transition-colors">
                    Choose file
                    <input type="file" className="hidden" />
                  </label>
                  <span className="px-4 py-2 text-slate-400">No file chosen</span>
                </div>
              </div>

            </div>

            {/* Drawer Footer / Actions */}
            <div className="mt-8 flex justify-end gap-3">
              <button 
                type="button" 
                onClick={() => setIsModalOpen(false)}
                className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 font-medium px-4 py-2 rounded-md transition-colors shadow-sm"
              >
                Cancel
              </button>
              <button 
                type="button" 
                className="bg-emerald-500 hover:bg-emerald-600 text-white font-medium px-6 py-2 rounded-md transition-colors shadow-sm"
              >
                Save
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}