import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';

export default function RootLayout() {
  // Tip: In the future, consider using useLocation() from react-router-dom 
  // to set the active nav based on the actual URL rather than local state!
  const [activeNav, setActiveNav] = useState('dashboard');

  return (
    <div className="flex h-screen bg-brand-50 font-sans overflow-hidden">
      {/* Sidebar - Fixed Left */}
      <Sidebar activeNav={activeNav} setActiveNav={setActiveNav} />

      {/* Main Content Area - Flexible Right */}
      <main className="flex-1 flex flex-col">
        
        {/* Top Header */}
        <Header />

        {/* Dynamic Content based on Sidebar Nav */}
        <div className="flex-1 overflow-hidden">
          {/* Outlet renders the child routes defined in App.jsx */}
          <Outlet />
        </div>
      </main>
    </div>
  );
}